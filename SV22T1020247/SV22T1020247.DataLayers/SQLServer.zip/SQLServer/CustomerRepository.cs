﻿using Dapper;
using Microsoft.Data.SqlClient;
using SV22T1020247.DataLayers.Interfaces;
using SV22T1020247.Models.Common;
using SV22T1020247.Models.Partner;

namespace SV22T1020247.DataLayers.SQLServer
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly string _connectionString;

        /// <summary>
        /// Constructor nhận chuỗi kết nối từ cấu hình
        /// </summary>
        /// <param name="connectionString">Chuỗi kết nối CSDL</param>
        public CustomerRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<int> AddAsync(Customer data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                INSERT INTO Customers (CustomerName, ContactName, Province, Address, Phone, Email, IsLocked)
                VALUES (@CustomerName, @ContactName, @Province, @Address, @Phone, @Email, @IsLocked);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            // Trả về ID vừa được tự động sinh ra cho Customer
            return await connection.ExecuteScalarAsync<int>(sql, data);
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"DELETE FROM Customers WHERE CustomerID = @CustomerID";

            var result = await connection.ExecuteAsync(sql, new { CustomerID = id });
            return result > 0;
        }

        public async Task<Customer?> GetAsync(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"SELECT * FROM Customers WHERE CustomerID = @CustomerID";

            return await connection.QueryFirstOrDefaultAsync<Customer>(sql, new { CustomerID = id });
        }

        public async Task<bool> IsUsed(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            // Kiểm tra xem Khách hàng này đã từng có đơn hàng nào chưa
            var sql = @"
                SELECT CASE WHEN EXISTS(
                    SELECT 1 FROM Orders WHERE CustomerID = @CustomerID
                ) THEN 1 ELSE 0 END";

            return await connection.ExecuteScalarAsync<bool>(sql, new { CustomerID = id });
        }

        public async Task<PagedResult<Customer>> ListAsync(PaginationSearchInput input)
        {
            using var connection = new SqlConnection(_connectionString);

            string searchValue = $"%{input.SearchValue}%";

            // Tìm kiếm theo Tên khách hàng, Tên giao dịch, Điện thoại hoặc Email
            string countSql = @"
                SELECT COUNT(*) 
                FROM Customers 
                WHERE (@SearchValue = N'') 
                   OR (CustomerName LIKE @LikeSearchValue 
                       OR ContactName LIKE @LikeSearchValue 
                       OR Phone LIKE @LikeSearchValue 
                       OR Email LIKE @LikeSearchValue)";

            string dataSql = @"
                SELECT * FROM Customers 
                WHERE (@SearchValue = N'') 
                   OR (CustomerName LIKE @LikeSearchValue 
                       OR ContactName LIKE @LikeSearchValue 
                       OR Phone LIKE @LikeSearchValue 
                       OR Email LIKE @LikeSearchValue)
                ORDER BY CustomerName
                OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";

            if (input.PageSize == 0)
            {
                dataSql = @"
                    SELECT * FROM Customers 
                    WHERE (@SearchValue = N'') 
                       OR (CustomerName LIKE @LikeSearchValue 
                           OR ContactName LIKE @LikeSearchValue 
                           OR Phone LIKE @LikeSearchValue 
                           OR Email LIKE @LikeSearchValue)
                    ORDER BY CustomerName";
            }

            var parameters = new
            {
                SearchValue = input.SearchValue ?? "",
                LikeSearchValue = searchValue,
                Offset = input.Offset,
                PageSize = input.PageSize
            };

            int rowCount = await connection.ExecuteScalarAsync<int>(countSql, parameters);
            var dataItems = await connection.QueryAsync<Customer>(dataSql, parameters);

            return new PagedResult<Customer>
            {
                Page = input.Page,
                PageSize = input.PageSize,
                RowCount = rowCount,
                DataItems = dataItems.ToList()
            };
        }

        public async Task<bool> UpdateAsync(Customer data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                UPDATE Customers 
                SET CustomerName = @CustomerName, 
                    ContactName = @ContactName, 
                    Province = @Province, 
                    Address = @Address, 
                    Phone = @Phone, 
                    Email = @Email, 
                    IsLocked = @IsLocked
                WHERE CustomerID = @CustomerID";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }

        public async Task<bool> ValidateEmailAsync(string email, int id = 0)
        {
            using var connection = new SqlConnection(_connectionString);
            // Kiểm tra xem email này đã tồn tại trong CSDL nhưng thuộc về một CustomerID khác hay chưa
            // Trả về true (1) nếu email chưa bị trùng (hợp lệ), false (0) nếu đã bị trùng.
            var sql = @"
                SELECT CASE WHEN EXISTS(
                    SELECT 1 FROM Customers WHERE Email = @Email AND CustomerID <> @CustomerID
                ) THEN 0 ELSE 1 END";

            return await connection.ExecuteScalarAsync<bool>(sql, new { Email = email, CustomerID = id });
        }
    }
}