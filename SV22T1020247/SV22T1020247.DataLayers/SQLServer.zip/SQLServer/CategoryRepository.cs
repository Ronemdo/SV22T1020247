﻿using Dapper;
using Microsoft.Data.SqlClient;
using SV22T1020247.DataLayers.Interfaces;
using SV22T1020247.Models.Catalog;
using SV22T1020247.Models.Common;

namespace SV22T1020247.DataLayers.SQLServer
{
    public class CategoryRepository : IGenericRepository<Category>
    {
        private readonly string _connectionString;

        /// <summary>
        /// Constructor nhận chuỗi kết nối từ cấu hình
        /// </summary>
        /// <param name="connectionString">Chuỗi kết nối CSDL</param>
        public CategoryRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<int> AddAsync(Category data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                INSERT INTO Categories (CategoryName, Description)
                VALUES (@CategoryName, @Description);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            // Trả về ID vừa được tự động sinh ra cho Category
            return await connection.ExecuteScalarAsync<int>(sql, data);
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"DELETE FROM Categories WHERE CategoryID = @CategoryID";

            var result = await connection.ExecuteAsync(sql, new { CategoryID = id });
            return result > 0;
        }

        public async Task<Category?> GetAsync(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"SELECT * FROM Categories WHERE CategoryID = @CategoryID";

            return await connection.QueryFirstOrDefaultAsync<Category>(sql, new { CategoryID = id });
        }

        public async Task<bool> IsUsed(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            // Kiểm tra xem Loại hàng này đã có Mặt hàng (Product) nào tham chiếu tới chưa
            var sql = @"
                SELECT CASE WHEN EXISTS(
                    SELECT 1 FROM Products WHERE CategoryID = @CategoryID
                ) THEN 1 ELSE 0 END";

            return await connection.ExecuteScalarAsync<bool>(sql, new { CategoryID = id });
        }

        public async Task<PagedResult<Category>> ListAsync(PaginationSearchInput input)
        {
            using var connection = new SqlConnection(_connectionString);

            string searchValue = $"%{input.SearchValue}%";

            // Câu truy vấn đếm tổng số dòng (tìm theo tên Loại hàng hoặc Mô tả)
            string countSql = @"
                SELECT COUNT(*) 
                FROM Categories 
                WHERE (@SearchValue = N'') 
                   OR (CategoryName LIKE @LikeSearchValue OR Description LIKE @LikeSearchValue)";

            // Câu truy vấn lấy dữ liệu có phân trang
            string dataSql = @"
                SELECT * FROM Categories 
                WHERE (@SearchValue = N'') 
                   OR (CategoryName LIKE @LikeSearchValue OR Description LIKE @LikeSearchValue)
                ORDER BY CategoryName
                OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";

            // Xử lý trường hợp không phân trang (PageSize = 0)
            if (input.PageSize == 0)
            {
                dataSql = @"
                    SELECT * FROM Categories 
                    WHERE (@SearchValue = N'') 
                       OR (CategoryName LIKE @LikeSearchValue OR Description LIKE @LikeSearchValue)
                    ORDER BY CategoryName";
            }

            var parameters = new
            {
                SearchValue = input.SearchValue ?? "",
                LikeSearchValue = searchValue,
                Offset = input.Offset,
                PageSize = input.PageSize
            };

            // Thực thi truy vấn
            int rowCount = await connection.ExecuteScalarAsync<int>(countSql, parameters);
            var dataItems = await connection.QueryAsync<Category>(dataSql, parameters);

            return new PagedResult<Category>
            {
                Page = input.Page,
                PageSize = input.PageSize,
                RowCount = rowCount,
                DataItems = dataItems.ToList()
            };
        }

        public async Task<bool> UpdateAsync(Category data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                UPDATE Categories 
                SET CategoryName = @CategoryName, 
                    Description = @Description
                WHERE CategoryID = @CategoryID";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }
    }
}