﻿using Dapper;
using Microsoft.Data.SqlClient;
using SV22T1020247.DataLayers.Interfaces;
using SV22T1020247.Models.Catalog;
using SV22T1020247.Models.Common;

namespace SV22T1020247.DataLayers.SQLServer
{
    public class ProductRepository : IProductRepository
    {
        private readonly string _connectionString;

        public ProductRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        #region Các nghiệp vụ liên quan đến Mặt hàng (Product)

        public async Task<int> AddAsync(Product data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                INSERT INTO Products (ProductName, ProductDescription, SupplierID, CategoryID, Unit, Price, Photo, IsSelling)
                VALUES (@ProductName, @ProductDescription, @SupplierID, @CategoryID, @Unit, @Price, @Photo, @IsSelling);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            return await connection.ExecuteScalarAsync<int>(sql, data);
        }

        public async Task<bool> DeleteAsync(int productID)
        {
            using var connection = new SqlConnection(_connectionString);
            // Cần xóa các ảnh và thuộc tính liên quan trước khi xóa mặt hàng
            var sql = @"
                DELETE FROM ProductPhotos WHERE ProductID = @ProductID;
                DELETE FROM ProductAttributes WHERE ProductID = @ProductID;
                DELETE FROM Products WHERE ProductID = @ProductID;";

            var result = await connection.ExecuteAsync(sql, new { ProductID = productID });
            return result > 0;
        }

        public async Task<Product?> GetAsync(int productID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"SELECT * FROM Products WHERE ProductID = @ProductID";

            return await connection.QueryFirstOrDefaultAsync<Product>(sql, new { ProductID = productID });
        }

        public async Task<bool> IsUsedAsync(int productID)
        {
            using var connection = new SqlConnection(_connectionString);
            // Kiểm tra mặt hàng đã từng được bán trong chi tiết đơn hàng (OrderDetails) chưa
            var sql = @"
                SELECT CASE WHEN EXISTS(
                    SELECT 1 FROM OrderDetails WHERE ProductID = @ProductID
                ) THEN 1 ELSE 0 END";

            return await connection.ExecuteScalarAsync<bool>(sql, new { ProductID = productID });
        }

        public async Task<PagedResult<Product>> ListAsync(ProductSearchInput input)
        {
            using var connection = new SqlConnection(_connectionString);

            string searchValue = $"%{input.SearchValue}%";

            string countSql = @"
                SELECT COUNT(*) 
                FROM Products 
                WHERE (@SearchValue = N'' OR ProductName LIKE @LikeSearchValue)
                  AND (@CategoryID = 0 OR CategoryID = @CategoryID)
                  AND (@SupplierID = 0 OR SupplierID = @SupplierID)
                  AND (Price >= @MinPrice)
                  AND (@MaxPrice <= 0 OR Price <= @MaxPrice)";

            string dataSql = @"
                SELECT * FROM Products 
                WHERE (@SearchValue = N'' OR ProductName LIKE @LikeSearchValue)
                  AND (@CategoryID = 0 OR CategoryID = @CategoryID)
                  AND (@SupplierID = 0 OR SupplierID = @SupplierID)
                  AND (Price >= @MinPrice)
                  AND (@MaxPrice <= 0 OR Price <= @MaxPrice)
                ORDER BY ProductName
                OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";

            if (input.PageSize == 0)
            {
                dataSql = @"
                    SELECT * FROM Products 
                    WHERE (@SearchValue = N'' OR ProductName LIKE @LikeSearchValue)
                      AND (@CategoryID = 0 OR CategoryID = @CategoryID)
                      AND (@SupplierID = 0 OR SupplierID = @SupplierID)
                      AND (Price >= @MinPrice)
                      AND (@MaxPrice <= 0 OR Price <= @MaxPrice)
                    ORDER BY ProductName";
            }

            var parameters = new
            {
                SearchValue = input.SearchValue ?? "",
                LikeSearchValue = searchValue,
                CategoryID = input.CategoryID,
                SupplierID = input.SupplierID,
                MinPrice = input.MinPrice,
                MaxPrice = input.MaxPrice,
                Offset = input.Offset,
                PageSize = input.PageSize
            };

            int rowCount = await connection.ExecuteScalarAsync<int>(countSql, parameters);
            var dataItems = await connection.QueryAsync<Product>(dataSql, parameters);

            return new PagedResult<Product>
            {
                Page = input.Page,
                PageSize = input.PageSize,
                RowCount = rowCount,
                DataItems = dataItems.ToList()
            };
        }

        public async Task<bool> UpdateAsync(Product data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                UPDATE Products 
                SET ProductName = @ProductName, 
                    ProductDescription = @ProductDescription, 
                    SupplierID = @SupplierID, 
                    CategoryID = @CategoryID, 
                    Unit = @Unit, 
                    Price = @Price, 
                    Photo = @Photo, 
                    IsSelling = @IsSelling
                WHERE ProductID = @ProductID";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }

        #endregion

        #region Các nghiệp vụ liên quan đến Thuộc tính (ProductAttribute)

        public async Task<long> AddAttributeAsync(ProductAttribute data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                INSERT INTO ProductAttributes (ProductID, AttributeName, AttributeValue, DisplayOrder)
                VALUES (@ProductID, @AttributeName, @AttributeValue, @DisplayOrder);
                SELECT CAST(SCOPE_IDENTITY() AS BIGINT);";

            return await connection.ExecuteScalarAsync<long>(sql, data);
        }

        public async Task<bool> DeleteAttributeAsync(long attributeID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"DELETE FROM ProductAttributes WHERE AttributeID = @AttributeID";

            var result = await connection.ExecuteAsync(sql, new { AttributeID = attributeID });
            return result > 0;
        }

        public async Task<ProductAttribute?> GetAttributeAsync(long attributeID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"SELECT * FROM ProductAttributes WHERE AttributeID = @AttributeID";

            return await connection.QueryFirstOrDefaultAsync<ProductAttribute>(sql, new { AttributeID = attributeID });
        }

        public async Task<List<ProductAttribute>> ListAttributesAsync(int productID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                SELECT * FROM ProductAttributes 
                WHERE ProductID = @ProductID 
                ORDER BY DisplayOrder";

            var dataItems = await connection.QueryAsync<ProductAttribute>(sql, new { ProductID = productID });
            return dataItems.ToList();
        }

        public async Task<bool> UpdateAttributeAsync(ProductAttribute data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                UPDATE ProductAttributes 
                SET ProductID = @ProductID, 
                    AttributeName = @AttributeName, 
                    AttributeValue = @AttributeValue, 
                    DisplayOrder = @DisplayOrder
                WHERE AttributeID = @AttributeID";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }

        #endregion

        #region Các nghiệp vụ liên quan đến Ảnh (ProductPhoto)

        public async Task<long> AddPhotoAsync(ProductPhoto data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                INSERT INTO ProductPhotos (ProductID, Photo, Description, DisplayOrder, IsHidden)
                VALUES (@ProductID, @Photo, @Description, @DisplayOrder, @IsHidden);
                SELECT CAST(SCOPE_IDENTITY() AS BIGINT);";

            return await connection.ExecuteScalarAsync<long>(sql, data);
        }

        public async Task<bool> DeletePhotoAsync(long photoID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"DELETE FROM ProductPhotos WHERE PhotoID = @PhotoID";

            var result = await connection.ExecuteAsync(sql, new { PhotoID = photoID });
            return result > 0;
        }

        public async Task<ProductPhoto?> GetPhotoAsync(long photoID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"SELECT * FROM ProductPhotos WHERE PhotoID = @PhotoID";

            return await connection.QueryFirstOrDefaultAsync<ProductPhoto>(sql, new { PhotoID = photoID });
        }

        public async Task<List<ProductPhoto>> ListPhotosAsync(int productID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                SELECT * FROM ProductPhotos 
                WHERE ProductID = @ProductID 
                ORDER BY DisplayOrder";

            var dataItems = await connection.QueryAsync<ProductPhoto>(sql, new { ProductID = productID });
            return dataItems.ToList();
        }

        public async Task<bool> UpdatePhotoAsync(ProductPhoto data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                UPDATE ProductPhotos 
                SET ProductID = @ProductID, 
                    Photo = @Photo, 
                    Description = @Description, 
                    DisplayOrder = @DisplayOrder, 
                    IsHidden = @IsHidden
                WHERE PhotoID = @PhotoID";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }

        #endregion
    }
}