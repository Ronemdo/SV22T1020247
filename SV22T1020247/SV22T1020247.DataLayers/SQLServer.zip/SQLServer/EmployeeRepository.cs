﻿using Dapper;
using Microsoft.Data.SqlClient;
using SV22T1020247.DataLayers.Interfaces;
using SV22T1020247.Models.Common;
using SV22T1020247.Models.HR;

namespace SV22T1020247.DataLayers.SQLServer
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly string _connectionString;

        /// <summary>
        /// Constructor nhận chuỗi kết nối từ cấu hình
        /// </summary>
        /// <param name="connectionString">Chuỗi kết nối CSDL</param>
        public EmployeeRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<int> AddAsync(Employee data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                INSERT INTO Employees (FullName, BirthDate, Address, Phone, Email, Photo, IsWorking)
                VALUES (@FullName, @BirthDate, @Address, @Phone, @Email, @Photo, @IsWorking);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            // Trả về ID vừa được tự động sinh ra cho Employee
            return await connection.ExecuteScalarAsync<int>(sql, data);
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"DELETE FROM Employees WHERE EmployeeID = @EmployeeID";

            var result = await connection.ExecuteAsync(sql, new { EmployeeID = id });
            return result > 0;
        }

        public async Task<Employee?> GetAsync(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"SELECT * FROM Employees WHERE EmployeeID = @EmployeeID";

            return await connection.QueryFirstOrDefaultAsync<Employee>(sql, new { EmployeeID = id });
        }

        public async Task<bool> IsUsed(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            // Kiểm tra xem Nhân viên này đã phụ trách (tạo/duyệt) đơn hàng nào trong bảng Orders chưa
            var sql = @"
                SELECT CASE WHEN EXISTS(
                    SELECT 1 FROM Orders WHERE EmployeeID = @EmployeeID
                ) THEN 1 ELSE 0 END";

            return await connection.ExecuteScalarAsync<bool>(sql, new { EmployeeID = id });
        }

        public async Task<PagedResult<Employee>> ListAsync(PaginationSearchInput input)
        {
            using var connection = new SqlConnection(_connectionString);

            string searchValue = $"%{input.SearchValue}%";

            // Câu truy vấn đếm tổng số dòng (tìm theo Họ tên, Số điện thoại hoặc Email)
            string countSql = @"
                SELECT COUNT(*) 
                FROM Employees 
                WHERE (@SearchValue = N'') 
                   OR (FullName LIKE @LikeSearchValue 
                       OR Phone LIKE @LikeSearchValue 
                       OR Email LIKE @LikeSearchValue)";

            // Câu truy vấn lấy dữ liệu có phân trang
            string dataSql = @"
                SELECT * FROM Employees 
                WHERE (@SearchValue = N'') 
                   OR (FullName LIKE @LikeSearchValue 
                       OR Phone LIKE @LikeSearchValue 
                       OR Email LIKE @LikeSearchValue)
                ORDER BY FullName
                OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";

            // Xử lý trường hợp không phân trang (PageSize = 0)
            if (input.PageSize == 0)
            {
                dataSql = @"
                    SELECT * FROM Employees 
                    WHERE (@SearchValue = N'') 
                       OR (FullName LIKE @LikeSearchValue 
                           OR Phone LIKE @LikeSearchValue 
                           OR Email LIKE @LikeSearchValue)
                    ORDER BY FullName";
            }

            var parameters = new
            {
                SearchValue = input.SearchValue ?? "",
                LikeSearchValue = searchValue,
                Offset = input.Offset,
                PageSize = input.PageSize
            };

            int rowCount = await connection.ExecuteScalarAsync<int>(countSql, parameters);
            var dataItems = await connection.QueryAsync<Employee>(dataSql, parameters);

            return new PagedResult<Employee>
            {
                Page = input.Page,
                PageSize = input.PageSize,
                RowCount = rowCount,
                DataItems = dataItems.ToList()
            };
        }

        public async Task<bool> UpdateAsync(Employee data)
        {
            using var connection = new SqlConnection(_connectionString);
            // Lưu ý: Các trường Password hoặc RoleNames nếu có cập nhật riêng thì có thể tách ra, 
            // ở đây ta cập nhật theo thông tin từ Model truyền vào.
            var sql = @"
                UPDATE Employees 
                SET FullName = @FullName, 
                    BirthDate = @BirthDate, 
                    Address = @Address, 
                    Phone = @Phone, 
                    Email = @Email, 
                    Photo = @Photo,
                    IsWorking = @IsWorking
                WHERE EmployeeID = @EmployeeID";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }

        public async Task<bool> ValidateEmailAsync(string email, int id = 0)
        {
            using var connection = new SqlConnection(_connectionString);
            // Trả về true (1) nếu email chưa bị dùng bởi nhân viên khác, false (0) nếu đã bị trùng.
            var sql = @"
                SELECT CASE WHEN EXISTS(
                    SELECT 1 FROM Employees WHERE Email = @Email AND EmployeeID <> @EmployeeID
                ) THEN 0 ELSE 1 END";

            return await connection.ExecuteScalarAsync<bool>(sql, new { Email = email, EmployeeID = id });
        }
    }
}