﻿using Dapper;
using Microsoft.Data.SqlClient;
using SV22T1020247.DataLayers.Interfaces;
using SV22T1020247.Models.DataDictionary;

namespace SV22T1020247.DataLayers.SQLServer
{
    public class ProvinceRepository : IDataDictionaryRepository<Province>
    {
        private readonly string _connectionString;

        /// <summary>
        /// Constructor nhận chuỗi kết nối từ cấu hình
        /// </summary>
        /// <param name="connectionString">Chuỗi kết nối CSDL</param>
        public ProvinceRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<List<Province>> ListAsync()
        {
            using var connection = new SqlConnection(_connectionString);

            // Lấy danh sách các tỉnh/thành phố và sắp xếp theo bảng chữ cái để hiển thị đẹp hơn trên giao diện
            var sql = @"SELECT ProvinceName FROM Provinces ORDER BY ProvinceName";

            var dataItems = await connection.QueryAsync<Province>(sql);

            return dataItems.ToList();
        }
    }
}