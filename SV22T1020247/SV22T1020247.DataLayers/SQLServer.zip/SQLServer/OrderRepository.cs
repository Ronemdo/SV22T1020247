﻿using Dapper;
using Microsoft.Data.SqlClient;
using SV22T1020247.DataLayers.Interfaces;
using SV22T1020247.Models.Common;
using SV22T1020247.Models.Sales;

namespace SV22T1020247.DataLayers.SQLServer
{
    public class OrderRepository : IOrderRepository
    {
        private readonly string _connectionString;

        public OrderRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<int> AddAsync(Order data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                INSERT INTO Orders (CustomerID, OrderTime, DeliveryProvince, DeliveryAddress, EmployeeID, AcceptTime, ShipperID, ShippedTime, FinishedTime, Status)
                VALUES (@CustomerID, @OrderTime, @DeliveryProvince, @DeliveryAddress, @EmployeeID, @AcceptTime, @ShipperID, @ShippedTime, @FinishedTime, @Status);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            return await connection.ExecuteScalarAsync<int>(sql, data);
        }

        public async Task<bool> AddDetailAsync(OrderDetail data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                INSERT INTO OrderDetails (OrderID, ProductID, Quantity, SalePrice)
                VALUES (@OrderID, @ProductID, @Quantity, @SalePrice)";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }

        public async Task<bool> DeleteAsync(int orderID)
        {
            using var connection = new SqlConnection(_connectionString);
            // Cần xóa chi tiết đơn hàng (OrderDetails) trước để tránh lỗi ràng buộc khóa ngoại
            var sql = @"
                DELETE FROM OrderDetails WHERE OrderID = @OrderID;
                DELETE FROM Orders WHERE OrderID = @OrderID;";

            var result = await connection.ExecuteAsync(sql, new { OrderID = orderID });
            return result > 0;
        }

        public async Task<bool> DeleteDetailAsync(int orderID, int productID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"DELETE FROM OrderDetails WHERE OrderID = @OrderID AND ProductID = @ProductID";

            var result = await connection.ExecuteAsync(sql, new { OrderID = orderID, ProductID = productID });
            return result > 0;
        }

        public async Task<OrderViewInfo?> GetAsync(int orderID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                SELECT o.*,
                       c.CustomerName,
                       c.ContactName as CustomerContactName,
                       c.Address as CustomerAddress,
                       c.Phone as CustomerPhone,
                       c.Email as CustomerEmail,
                       e.FullName as EmployeeName,
                       s.ShipperName,
                       s.Phone as ShipperPhone
                FROM Orders o
                LEFT JOIN Customers c ON o.CustomerID = c.CustomerID
                LEFT JOIN Employees e ON o.EmployeeID = e.EmployeeID
                LEFT JOIN Shippers s ON o.ShipperID = s.ShipperID
                WHERE o.OrderID = @OrderID";

            return await connection.QueryFirstOrDefaultAsync<OrderViewInfo>(sql, new { OrderID = orderID });
        }

        public async Task<OrderDetailViewInfo?> GetDetailAsync(int orderID, int productID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                SELECT od.*, p.ProductName, p.Photo, p.Unit
                FROM OrderDetails od
                JOIN Products p ON od.ProductID = p.ProductID
                WHERE od.OrderID = @OrderID AND od.ProductID = @ProductID";

            return await connection.QueryFirstOrDefaultAsync<OrderDetailViewInfo>(sql, new { OrderID = orderID, ProductID = productID });
        }

        public async Task<PagedResult<OrderViewInfo>> ListAsync(OrderSearchInput input)
        {
            using var connection = new SqlConnection(_connectionString);

            string searchValue = $"%{input.SearchValue}%";

            // Lọc theo Status: Nếu Status == 0 (không nằm trong enum hiện tại), ta coi như là lấy tất cả.
            int statusFilter = (int)input.Status;

            string countSql = @"
                SELECT COUNT(*) 
                FROM Orders o
                LEFT JOIN Customers c ON o.CustomerID = c.CustomerID
                LEFT JOIN Employees e ON o.EmployeeID = e.EmployeeID
                WHERE (@SearchValue = N'' OR c.CustomerName LIKE @SearchValue OR e.FullName LIKE @SearchValue)
                  AND (@Status = 0 OR o.Status = @Status)
                  AND (@DateFrom IS NULL OR CAST(o.OrderTime AS DATE) >= CAST(@DateFrom AS DATE))
                  AND (@DateTo IS NULL OR CAST(o.OrderTime AS DATE) <= CAST(@DateTo AS DATE))";

            string dataSql = @"
                SELECT o.*,
                       c.CustomerName,
                       c.ContactName as CustomerContactName,
                       c.Address as CustomerAddress,
                       c.Phone as CustomerPhone,
                       c.Email as CustomerEmail,
                       e.FullName as EmployeeName,
                       s.ShipperName,
                       s.Phone as ShipperPhone
                FROM Orders o
                LEFT JOIN Customers c ON o.CustomerID = c.CustomerID
                LEFT JOIN Employees e ON o.EmployeeID = e.EmployeeID
                LEFT JOIN Shippers s ON o.ShipperID = s.ShipperID
                WHERE (@SearchValue = N'' OR c.CustomerName LIKE @SearchValue OR e.FullName LIKE @SearchValue)
                  AND (@Status = 0 OR o.Status = @Status)
                  AND (@DateFrom IS NULL OR CAST(o.OrderTime AS DATE) >= CAST(@DateFrom AS DATE))
                  AND (@DateTo IS NULL OR CAST(o.OrderTime AS DATE) <= CAST(@DateTo AS DATE))
                ORDER BY o.OrderTime DESC
                OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";

            // Nếu PageSize = 0 (Lấy tất cả)
            if (input.PageSize == 0)
            {
                dataSql = @"
                    SELECT o.*,
                           c.CustomerName,
                           c.ContactName as CustomerContactName,
                           c.Address as CustomerAddress,
                           c.Phone as CustomerPhone,
                           c.Email as CustomerEmail,
                           e.FullName as EmployeeName,
                           s.ShipperName,
                           s.Phone as ShipperPhone
                    FROM Orders o
                    LEFT JOIN Customers c ON o.CustomerID = c.CustomerID
                    LEFT JOIN Employees e ON o.EmployeeID = e.EmployeeID
                    LEFT JOIN Shippers s ON o.ShipperID = s.ShipperID
                    WHERE (@SearchValue = N'' OR c.CustomerName LIKE @SearchValue OR e.FullName LIKE @SearchValue)
                      AND (@Status = 0 OR o.Status = @Status)
                      AND (@DateFrom IS NULL OR CAST(o.OrderTime AS DATE) >= CAST(@DateFrom AS DATE))
                      AND (@DateTo IS NULL OR CAST(o.OrderTime AS DATE) <= CAST(@DateTo AS DATE))
                    ORDER BY o.OrderTime DESC";
            }

            var parameters = new
            {
                SearchValue = input.SearchValue ?? "",
                Status = statusFilter,
                DateFrom = input.DateFrom,
                DateTo = input.DateTo,
                Offset = input.Offset,
                PageSize = input.PageSize
            };

            int rowCount = await connection.ExecuteScalarAsync<int>(countSql, parameters);
            var dataItems = await connection.QueryAsync<OrderViewInfo>(dataSql, parameters);

            return new PagedResult<OrderViewInfo>
            {
                Page = input.Page,
                PageSize = input.PageSize,
                RowCount = rowCount,
                DataItems = dataItems.ToList()
            };
        }

        public async Task<List<OrderDetailViewInfo>> ListDetailsAsync(int orderID)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                SELECT od.*, p.ProductName, p.Photo, p.Unit
                FROM OrderDetails od
                JOIN Products p ON od.ProductID = p.ProductID
                WHERE od.OrderID = @OrderID
                ORDER BY p.ProductName";

            var data = await connection.QueryAsync<OrderDetailViewInfo>(sql, new { OrderID = orderID });
            return data.ToList();
        }

        public async Task<bool> UpdateAsync(Order data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                UPDATE Orders 
                SET CustomerID = @CustomerID, 
                    OrderTime = @OrderTime, 
                    DeliveryProvince = @DeliveryProvince, 
                    DeliveryAddress = @DeliveryAddress, 
                    EmployeeID = @EmployeeID, 
                    AcceptTime = @AcceptTime, 
                    ShipperID = @ShipperID, 
                    ShippedTime = @ShippedTime, 
                    FinishedTime = @FinishedTime, 
                    Status = @Status
                WHERE OrderID = @OrderID";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }

        public async Task<bool> UpdateDetailAsync(OrderDetail data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                UPDATE OrderDetails 
                SET Quantity = @Quantity, 
                    SalePrice = @SalePrice
                WHERE OrderID = @OrderID AND ProductID = @ProductID";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }
    }
}