﻿using Dapper;
using Microsoft.Data.SqlClient;
using SV22T1020247.DataLayers.Interfaces;
using SV22T1020247.Models.Common;
using SV22T1020247.Models.Partner;

namespace SV22T1020247.DataLayers.SQLServer
{
    public class ShipperRepository : IGenericRepository<Shipper>
    {
        private readonly string _connectionString;

        /// <summary>
        /// Constructor nhận chuỗi kết nối từ cấu hình
        /// </summary>
        /// <param name="connectionString">Chuỗi kết nối CSDL</param>
        public ShipperRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<int> AddAsync(Shipper data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                INSERT INTO Shippers (ShipperName, Phone)
                VALUES (@ShipperName, @Phone);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            // Trả về ID vừa được tự động sinh ra cho Shipper
            return await connection.ExecuteScalarAsync<int>(sql, data);
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"DELETE FROM Shippers WHERE ShipperID = @ShipperID";

            var result = await connection.ExecuteAsync(sql, new { ShipperID = id });
            return result > 0;
        }

        public async Task<Shipper?> GetAsync(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"SELECT * FROM Shippers WHERE ShipperID = @ShipperID";

            return await connection.QueryFirstOrDefaultAsync<Shipper>(sql, new { ShipperID = id });
        }

        public async Task<bool> IsUsed(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            // Kiểm tra xem Shipper này đã được phân công giao đơn hàng nào trong bảng Orders chưa
            var sql = @"
                SELECT CASE WHEN EXISTS(
                    SELECT 1 FROM Orders WHERE ShipperID = @ShipperID
                ) THEN 1 ELSE 0 END";

            return await connection.ExecuteScalarAsync<bool>(sql, new { ShipperID = id });
        }

        public async Task<PagedResult<Shipper>> ListAsync(PaginationSearchInput input)
        {
            using var connection = new SqlConnection(_connectionString);

            string searchValue = $"%{input.SearchValue}%";

            // Câu truy vấn đếm tổng số dòng (tìm theo tên Shipper hoặc Số điện thoại)
            string countSql = @"
                SELECT COUNT(*) 
                FROM Shippers 
                WHERE (@SearchValue = N'') 
                   OR (ShipperName LIKE @LikeSearchValue OR Phone LIKE @LikeSearchValue)";

            // Câu truy vấn lấy dữ liệu có phân trang
            string dataSql = @"
                SELECT * FROM Shippers 
                WHERE (@SearchValue = N'') 
                   OR (ShipperName LIKE @LikeSearchValue OR Phone LIKE @LikeSearchValue)
                ORDER BY ShipperName
                OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";

            // Xử lý trường hợp không phân trang (PageSize = 0)
            if (input.PageSize == 0)
            {
                dataSql = @"
                    SELECT * FROM Shippers 
                    WHERE (@SearchValue = N'') 
                       OR (ShipperName LIKE @LikeSearchValue OR Phone LIKE @LikeSearchValue)
                    ORDER BY ShipperName";
            }

            var parameters = new
            {
                SearchValue = input.SearchValue ?? "",
                LikeSearchValue = searchValue,
                Offset = input.Offset,
                PageSize = input.PageSize
            };

            // Chạy 2 câu truy vấn song song (tuỳ chọn) hoặc tuần tự
            int rowCount = await connection.ExecuteScalarAsync<int>(countSql, parameters);
            var dataItems = await connection.QueryAsync<Shipper>(dataSql, parameters);

            return new PagedResult<Shipper>
            {
                Page = input.Page,
                PageSize = input.PageSize,
                RowCount = rowCount,
                DataItems = dataItems.ToList()
            };
        }

        public async Task<bool> UpdateAsync(Shipper data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                UPDATE Shippers 
                SET ShipperName = @ShipperName, 
                    Phone = @Phone
                WHERE ShipperID = @ShipperID";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }
    }
}