﻿using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;
using SV22T1020247.DataLayers.Interfaces;
using SV22T1020247.Models.Common;
using SV22T1020247.Models.Partner;

namespace SV22T1020247.DataLayers.SQLServer
{
    public class SupplierRepository : IGenericRepository<Supplier>
    {
        private readonly string _connectionString;

        /// <summary>
        /// Constructor nhận chuỗi kết nối từ cấu hình (ví dụ: appsettings.json)
        /// </summary>
        /// <param name="connectionString">Chuỗi kết nối CSDL</param>
        public SupplierRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<int> AddAsync(Supplier data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                INSERT INTO Suppliers (SupplierName, ContactName, Province, Address, Phone, Email)
                VALUES (@SupplierName, @ContactName, @Province, @Address, @Phone, @Email);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            // Trả về ID vừa được tự động sinh ra
            return await connection.ExecuteScalarAsync<int>(sql, data);
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"DELETE FROM Suppliers WHERE SupplierID = @SupplierID";

            var result = await connection.ExecuteAsync(sql, new { SupplierID = id });
            return result > 0;
        }

        public async Task<Supplier?> GetAsync(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"SELECT * FROM Suppliers WHERE SupplierID = @SupplierID";

            return await connection.QueryFirstOrDefaultAsync<Supplier>(sql, new { SupplierID = id });
        }

        public async Task<bool> IsUsed(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            // Kiểm tra xem SupplierID này đã được dùng trong bảng Products chưa
            var sql = @"
                SELECT CASE WHEN EXISTS(
                    SELECT 1 FROM Products WHERE SupplierID = @SupplierID
                ) THEN 1 ELSE 0 END";

            return await connection.ExecuteScalarAsync<bool>(sql, new { SupplierID = id });
        }

        public async Task<PagedResult<Supplier>> ListAsync(PaginationSearchInput input)
        {
            using var connection = new SqlConnection(_connectionString);

            string searchValue = $"%{input.SearchValue}%";

            // Câu truy vấn đếm tổng số dòng thỏa mãn điều kiện tìm kiếm
            string countSql = @"
                SELECT COUNT(*) 
                FROM Suppliers 
                WHERE (@SearchValue = N'') 
                   OR (SupplierName LIKE @LikeSearchValue OR ContactName LIKE @LikeSearchValue)";

            // Câu truy vấn lấy dữ liệu phân trang
            string dataSql = @"
                SELECT * FROM Suppliers 
                WHERE (@SearchValue = N'') 
                   OR (SupplierName LIKE @LikeSearchValue OR ContactName LIKE @LikeSearchValue)
                ORDER BY SupplierName
                OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";

            if (input.PageSize == 0)
            {
                // Nếu PageSize = 0 (không phân trang), lấy tất cả
                dataSql = @"
                    SELECT * FROM Suppliers 
                    WHERE (@SearchValue = N'') 
                       OR (SupplierName LIKE @LikeSearchValue OR ContactName LIKE @LikeSearchValue)
                    ORDER BY SupplierName";
            }

            var parameters = new
            {
                SearchValue = input.SearchValue,
                LikeSearchValue = searchValue,
                Offset = input.Offset,
                PageSize = input.PageSize
            };

            // Thực thi đếm số dòng
            int rowCount = await connection.ExecuteScalarAsync<int>(countSql, parameters);

            // Thực thi lấy dữ liệu
            var dataItems = await connection.QueryAsync<Supplier>(dataSql, parameters);

            return new PagedResult<Supplier>
            {
                Page = input.Page,
                PageSize = input.PageSize,
                RowCount = rowCount,
                DataItems = dataItems.ToList()
            };
        }

        public async Task<bool> UpdateAsync(Supplier data)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = @"
                UPDATE Suppliers 
                SET SupplierName = @SupplierName, 
                    ContactName = @ContactName, 
                    Province = @Province, 
                    Address = @Address, 
                    Phone = @Phone, 
                    Email = @Email
                WHERE SupplierID = @SupplierID";

            var result = await connection.ExecuteAsync(sql, data);
            return result > 0;
        }
    }
}